﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;

namespace SeleniumWebDriver
{
    [TestClass]
    public class ValTechTest

    {
        [TestMethod]
        public void TestRecentBlogDisplay()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://www.valtech.co.uk.org/");
            Assert.IsTrue(driver.PageSource.Contains("Recent Blogs"));
            driver.Close();
            driver.Quit();
        }

        [TestMethod]
        public void TestABOUTtagdisplayInfo()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://www.valtech.co.uk.org/");
            driver.FindElement(By.LinkText("ABOUT"));
            //Verify code to assert that h1 tag contains About goes here
            driver.Close();
            driver.Quit();
        }

        [TestMethod]
        public void TestSERVICEStagdisplayInfo()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://www.valtech.co.uk.org/");
            driver.FindElement(By.LinkText("SERVICES"));
            //Verify code to assert that h1 tag contains services goes here

            driver.Close();
            driver.Quit();
        }


        [TestMethod]
        public void TestCONTACTtagdisplayInfo()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://www.valtech.co.uk.org/");
            driver.FindElement(By.LinkText("CONTACT"));
            //Verify code to assert that h1 tag contains services goes here

            driver.Close();
            driver.Quit();
        }

    }
}
